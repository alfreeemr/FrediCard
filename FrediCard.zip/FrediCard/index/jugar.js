document.getElementById("jugar-btn").addEventListener("click", function () {
  // Redireccionar a la página de selección de jugadores
  window.location.href = "../seleccion_jugadores/index.html";
});
